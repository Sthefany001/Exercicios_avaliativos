﻿public class Program
{
	static void Main(string[] args)
	{
        JogoDaVelha jogo = new JogoDaVelha();

        jogo.Jogar();
    }
}
